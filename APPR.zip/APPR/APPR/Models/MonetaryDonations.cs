﻿namespace APPR.Models
{
    public class MonetaryDonations
    {
        public int ID { get; set; }
        public int Amount { get; set; }
        public string Donor { get; set; }
        public DateTime Date { get; set; }

    }
}
