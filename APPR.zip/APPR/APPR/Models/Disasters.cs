﻿using static Humanizer.On;
using System.Drawing;
using System.Security.Principal;

namespace APPR.Models
{
    public class Disasters
    {
        public int ID { get; set; }
        public string Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Location { get; set; }
        public string RequiredAid { get; set; }

    }
}
