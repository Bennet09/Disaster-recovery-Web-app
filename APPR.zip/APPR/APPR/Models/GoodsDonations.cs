﻿using System.ComponentModel.DataAnnotations;

namespace APPR.Models
{
    public class GoodsDonations
    {      
        public int ID { get; set; }
        public string? Catergory { get; set; }
        public int NumberOfItems { get; set; }
        public DateTime Date { get; set; }
    }
}
