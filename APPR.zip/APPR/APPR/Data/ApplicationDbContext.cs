﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using APPR.Models;

namespace APPR.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<APPR.Models.Disasters>? Disasters { get; set; }
        public DbSet<APPR.Models.GoodsDonations>? GoodsDonations { get; set; }
        public DbSet<APPR.Models.MonetaryDonations>? MonetaryDonations { get; set; }

    }
}